"""
NetBenefits Page Prioritization Application

Main application file that coordinates all components.

How it works:
1. Load data from Excel
2. Apply filters from sidebar
3. Let users adjust weights for each profile
4. Calculate and display priority rankings
5. Provide exploration tools

File Structure:
- app.py (this file) - main coordination
- saved_weights.py - editable weight configurations
- config.py - column mappings and feature groups
- data_handler.py - data loading and filtering
- calculations.py - priority calculation logic
- state_management.py - profile management
- ui_components.py - reusable UI elements
- comparison_mode.py - results display and future comparison features
- visualization.py - exploration charts

To run: streamlit run app.py
"""

import pandas as pd
import streamlit as st

from config import CONFIGURATIONS
from data_handler import load_data, apply_all_filters
from calculations import calculate_priority_df
from state_management import (
    initialize_profiles,
    add_profile,
    remove_profile
)
from ui_components import (
    render_header,
    render_sliders
)
from comparison_mode import display_results_for_profile
from visualization import render_exploration_section

# Set page layout to wide
st.set_page_config(layout="wide")

# Load data
df = load_data('data.xlsx')

# Render header
render_header()

# Initialize session state for profiles
initialize_profiles()

# Apply filters from sidebar
filtered_df = apply_all_filters(df, st.sidebar)

# Weight adjustment UI
st.header('Adjust Feature Weights (Scale 0-5)')

col_add, col_remove, _ = st.columns([0.15, 0.15, 0.7])

if len(st.session_state.weight_profiles) < 5:
    col_add.button(
        "➕ Add Profile",
        on_click=add_profile,
        use_container_width=True
    )

if len(st.session_state.weight_profiles) > 1:
    col_remove.button(
        "➖ Remove Last",
        on_click=remove_profile,
        args=(len(st.session_state.weight_profiles) - 1,),
        use_container_width=True
    )

# Create tabs for each profile
tab_names = [p['name'] for p in st.session_state.weight_profiles]
tabs = st.tabs(tab_names)

# Render each profile
for i, profile in enumerate(st.session_state.weight_profiles):
    with tabs[i]:
        render_sliders(i, st.container())
        st.markdown("---")
        
        priority_df = calculate_priority_df(filtered_df, profile)
        display_results_for_profile(priority_df, profile['name'])

# Exploration section
render_exploration_section(df)

st.markdown("---")
