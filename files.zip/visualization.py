"""
Visualization Module

Handles data exploration visualizations including bar charts and scatter plots.
"""

import streamlit as st
import matplotlib.pyplot as plt
import plotly.express as px
from sklearn.linear_model import LinearRegression
from config import CUSTOM_DISPLAY_NAMES


def render_exploration_section(df):
    """Render the data exploration section with plot generators."""
    st.markdown("---")
    st.header("Column-wise Data Exploration")
    
    plot_type = st.selectbox("Select plot type", ["Bar (Top 10)", "Scatter"])
    base_cols = list(CUSTOM_DISPLAY_NAMES.keys())
    
    if plot_type == "Bar (Top 10)":
        selected_column = st.selectbox("Select column", base_cols)
        
        if st.button("Generate Bar Plot"):
            generate_bar_plot(df, selected_column)
    
    elif plot_type == "Scatter":
        col_x, col_y = st.columns(2)
        
        with col_x:
            x_axis = st.selectbox("X-axis", base_cols, index=0)
        
        with col_y:
            y_axis = st.selectbox("Y-axis", base_cols, index=1)
        
        if st.button("Generate Scatter Plot"):
            generate_scatter_plot(df, x_axis, y_axis)


def generate_bar_plot(df, column_name):
    """
    Generate horizontal bar chart showing top/bottom 10 pages for a metric.
    
    For satisfaction metrics (TOPBOX), shows bottom 10 (worst scores).
    For other metrics, shows top 10 (highest values).
    """
    ascending_sort = True if 'TOPBOX' in column_name else False
    
    top_10 = df[['PAGE_GROUP', column_name]].dropna().sort_values(
        by=column_name,
        ascending=ascending_sort
    ).head(10)
    
    fig, ax = plt.subplots(figsize=(10, 6))
    ax.barh(top_10['PAGE_GROUP'], top_10[column_name], color='darkorange')
    
    title_prefix = 'Bottom' if ascending_sort else 'Top'
    ax.set_title(f"{title_prefix} 10 - {CUSTOM_DISPLAY_NAMES.get(column_name, column_name)}")
    ax.invert_yaxis()
    
    st.pyplot(fig)


def generate_scatter_plot(df, x_column, y_column):
    """
    Generate interactive scatter plot with linear regression.
    Shows R-squared to indicate correlation strength.
    """
    df_plot = df[['PAGE_GROUP', x_column, y_column]].dropna()
    
    if df_plot.empty:
        st.warning("No data available for selected columns.")
        return
    
    # Calculate R-squared
    model = LinearRegression()
    X = df_plot[[x_column]]
    y = df_plot[y_column]
    model.fit(X, y)
    r_squared = model.score(X, y)
    
    st.info(f"Linear Correlation ($R^2$): {r_squared:.3f}")
    
    # Create scatter plot
    x_label = CUSTOM_DISPLAY_NAMES.get(x_column, x_column)
    y_label = CUSTOM_DISPLAY_NAMES.get(y_column, y_column)
    
    fig = px.scatter(
        df_plot,
        x=x_column,
        y=y_column,
        hover_name='PAGE_GROUP',
        title=f"{x_label} vs {y_label}",
        labels={
            x_column: x_label,
            y_column: y_label
        }
    )
    
    st.plotly_chart(fig, use_container_width=True)
