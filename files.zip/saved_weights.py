"""
Saved Weights Configuration

This file contains the weight configurations. Edit values here when you want to 
change how metrics are weighted in the priority calculation.

Weight Scale: 0 (no importance) to 5 (maximum importance)

Note: Keep the [value] format - just change the numbers inside the brackets.
"""

BASE_WEIGHTS = {
    "pg_visitors": [3],
    "friction_calls_weight": [3],
    "aht_weight": [3],
    "desktop_switch_rate_weight": [3],
    "pg_visits": [3],
    "visits_per_visitor_weight": [3],
    "call_rate_weight": [3],
    "ease_of_use_weight": [3],
    "cei_top2box_weight": [3],
    "friction_desktop_7day_weight": [3]
}

PRESET_WEIGHTS = {
    "Balanced": {
        "pg_visitors": [3],
        "friction_calls_weight": [3],
        "aht_weight": [3],
        "desktop_switch_rate_weight": [3],
        "pg_visits": [3],
        "visits_per_visitor_weight": [3],
        "call_rate_weight": [3],
        "ease_of_use_weight": [3],
        "cei_top2box_weight": [3],
        "friction_desktop_7day_weight": [3]
    },
    
    "Friction Focused": {
        "pg_visitors": [1],
        "friction_calls_weight": [5],
        "aht_weight": [4],
        "desktop_switch_rate_weight": [3],
        "pg_visits": [2],
        "visits_per_visitor_weight": [2],
        "call_rate_weight": [5],
        "ease_of_use_weight": [4],
        "cei_top2box_weight": [4],
        "friction_desktop_7day_weight": [5]
    },
    
    "Engagement Heavy": {
        "pg_visitors": [4],
        "friction_calls_weight": [2],
        "aht_weight": [1],
        "desktop_switch_rate_weight": [2],
        "pg_visits": [5],
        "visits_per_visitor_weight": [4],
        "call_rate_weight": [1],
        "ease_of_use_weight": [3],
        "cei_top2box_weight": [3],
        "friction_desktop_7day_weight": [1]
    }
}
