"""
Comparison Mode Module

Handles profile comparison functionality. Currently displays results for each profile
separately. Includes placeholder functions for future comparison features.
"""

import streamlit as st
import pandas as pd
from config import FEATURE_MAP_FOR_DISPLAY


def display_results_for_profile(priority_df, profile_name):
    """
    Display prioritization results for a single profile.
    Shows PAGE_GROUP, all metrics, and RawPriority score in a table.
    """
    feature_map = FEATURE_MAP_FOR_DISPLAY
    output_cols = ['PAGE_GROUP'] + list(feature_map.keys()) + ['RawPriority']
    
    st.subheader(f'{profile_name} - Prioritization Results')
    st.dataframe(
        priority_df[output_cols].reset_index(drop=True),
        use_container_width=True
    )


# ==========================================================================================
# FUTURE COMPARISON FUNCTIONS - Ready for implementation
# ==========================================================================================

def compare_profiles_side_by_side(profile_results_dict):
    """
    FUTURE: Display results from multiple profiles side-by-side.
    
    Could show:
    - Rank for each page across profiles
    - Rank changes between profiles
    - Which pages are "controversial" (vary widely in rank)
    
    To implement:
    1. Extract ranks from each profile
    2. Merge into comparison dataframe
    3. Calculate rank differences
    4. Display with appropriate styling
    """
    st.info("Side-by-side comparison feature - ready for implementation")
    pass


def highlight_rank_changes(profile_results_dict, threshold=5):
    """
    FUTURE: Highlight pages with significant rank changes across profiles.
    
    Useful for identifying which pages are affected most by weight changes.
    
    Parameters:
    - profile_results_dict: Dict of profile names to priority dataframes
    - threshold: Minimum rank change to highlight (default 5)
    """
    st.info("Rank change highlighting - ready for implementation")
    pass


def generate_comparison_report(profile_results_dict):
    """
    FUTURE: Generate downloadable Excel report comparing profiles.
    
    Could include:
    - Summary statistics for each profile
    - Top 10 pages for each profile
    - Pages with largest rank differences
    - Recommendations based on comparisons
    """
    st.info("Comparison report generation - ready for implementation")
    pass


def visualize_rank_distribution(profile_results_dict):
    """
    FUTURE: Show distribution of priority scores across profiles using box plots.
    
    Helps understand if weights create meaningful separation between pages.
    """
    st.info("Rank distribution visualization - ready for implementation")
    pass


def show_metric_contribution(priority_df, profile_weights):
    """
    FUTURE: Show how much each metric contributes to priority for top pages.
    
    Could use stacked bar chart to show breakdown of priority score components.
    Helps explain WHY a page has high priority.
    """
    st.info("Metric contribution analysis - ready for implementation")
    pass
