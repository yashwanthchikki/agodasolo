"""
Data Handler Module

Handles data loading and filtering operations.
"""

import pandas as pd
import streamlit as st


def load_data(filepath='data.xlsx'):
    """Load data from Excel file with error handling."""
    try:
        df = pd.read_excel(filepath)
        return df
    except FileNotFoundError:
        st.error(f"Error: '{filepath}' not found. Please ensure the data file is in the same directory.")
        st.stop()
        return None
    except Exception as e:
        st.error(f"Error loading data: {e}")
        st.stop()
        return None


def apply_category_filter(df, container=None):
    """Create category checkboxes and return filtered dataframe."""
    if 'CATEGORY' not in df.columns:
        return df
    
    render_container = container if container else st.sidebar
    
    with render_container.expander("Filter Categories", expanded=True):
        category_list = df['CATEGORY'].dropna().unique().tolist()
        selected_categories = [
            cat for cat in category_list 
            if st.checkbox(cat, value=True, key=f'c_{cat}')
        ]
    
    return df[df['CATEGORY'].isin(selected_categories)].copy()


def apply_subcategory_filter(df, container=None):
    """Create sub-category checkboxes and return filtered dataframe."""
    if 'SUB_CATEGORY' not in df.columns:
        return df
    
    render_container = container if container else st.sidebar
    
    with render_container.expander("Filter Sub-Categories", expanded=False):
        subcategory_list = df['SUB_CATEGORY'].dropna().unique().tolist()
        selected_subcategories = [
            sub for sub in subcategory_list 
            if st.checkbox(sub, value=True, key=f's_{sub}')
        ]
    
    return df[df['SUB_CATEGORY'].isin(selected_subcategories)]


def apply_transaction_filter(df, container=None):
    """Create transaction flag checkboxes and return filtered dataframe."""
    if 'Transaction Flag' not in df.columns:
        return df
    
    render_container = container if container else st.sidebar
    
    with render_container.expander("Transaction Status", expanded=True):
        transaction_options = sorted(
            df['Transaction Flag'].dropna().unique().astype(int).tolist()
        )
        selected_transactions = [
            trans for trans in transaction_options 
            if st.checkbox(f"Status {trans}", value=True, key=f't_{trans}')
        ]
    
    return df[df['Transaction Flag'].isin(selected_transactions)]


def apply_response_count_filter(df, container=None):
    """Apply minimum response count filter with toggle control."""
    if 'NUM_RESPONSES' not in df.columns:
        return df
    
    render_container = container if container else st.sidebar
    
    require_min_responses = render_container.toggle(
        "Require > 30 Responses", 
        value=False
    )
    
    if require_min_responses:
        return df[df['NUM_RESPONSES'] >= 30]
    else:
        return df


def apply_all_filters(df, sidebar_container=None):
    """Apply all filters in sequence and return final filtered dataframe."""
    container = sidebar_container if sidebar_container else st.sidebar
    container.markdown("### Data Filters (Universal)")
    
    filtered_df = apply_category_filter(df, container)
    filtered_df = apply_subcategory_filter(filtered_df, container)
    filtered_df = apply_transaction_filter(filtered_df, container)
    filtered_df = apply_response_count_filter(filtered_df, container)
    
    return filtered_df
