"""
Calculations Module

Contains priority calculation logic. This module has no UI dependencies
so it can be tested independently.

Priority Calculation Approach:
1. Normalize each metric to 0-1 scale (prevents large values from dominating)
2. Normalize weights to 0-1 scale
3. Invert satisfaction metrics (lower satisfaction = higher priority)
4. Calculate weighted sum of all metrics
5. Sort by priority score (highest first)
"""

import pandas as pd


def normalize(series):
    """
    Normalize a pandas Series to 0-1 scale using min-max normalization.
    Returns all zeros if series is empty or has no variance.
    """
    if series.empty or series.max() == series.min():
        return pd.Series(0.0, index=series.index)
    
    return (series - series.min()) / (series.max() - series.min())


def normalize_weights(weights_dict):
    """
    Normalize weight values from 0-5 scale to 0-1 scale.
    Preserves relative importance between weights.
    """
    from saved_weights import BASE_WEIGHTS
    
    weight_keys = list(BASE_WEIGHTS.keys())
    values = [weights_dict.get(k, [3])[0] for k in weight_keys]
    
    min_val = min(values)
    max_val = max(values)
    
    if max_val == min_val:
        return {k: 1.0 for k in weight_keys}
    
    return {
        k: (weights_dict.get(k, [3])[0] - min_val) / (max_val - min_val) 
        for k in weight_keys
    }


def calculate_priority_df(df_input, weight_profile):
    """
    Calculate priority scores for all pages based on normalized metrics and weights.
    
    Returns dataframe with normalized metrics and RawPriority score, sorted by priority.
    
    Note on satisfaction metrics:
    CEI_TOPBOX and EASE_OF_USE_TOPBOX are inverted using (100 - score) before normalization.
    This is because lower satisfaction scores should result in higher priority
    (those pages need more attention).
    """
    w_df = df_input.copy()
    
    # Normalize metrics to 0-1 scale
    w_df['n_visitors'] = normalize(w_df['VISITORS'])
    w_df['n_visits'] = normalize(w_df['VISITS'])
    w_df['n_vpv'] = normalize(w_df['Visits_per_Visitor'])
    w_df['n_calls'] = normalize(w_df['CALLS_7_DAYS'])
    w_df['n_aht'] = normalize(w_df['AVG_AHT'])
    w_df['n_call_rate'] = normalize(w_df['Call_Rate'])
    w_df['n_dsr'] = normalize(w_df['Desktop_switch_rate'])
    w_df['n_sw_desk'] = normalize(w_df['SWITCH_TO_DESKTOP'])
    
    # Satisfaction metrics are inverted - lower satisfaction = higher priority
    w_df['n_cei'] = normalize(100 - w_df['CEI_TOPBOX'])
    w_df['n_eou'] = normalize(100 - w_df['EASE_OF_USE_TOPBOX'])
    
    # Normalize weights
    nw = normalize_weights(weight_profile)
    
    # Calculate priority as weighted sum
    w_df['RawPriority'] = (
        w_df['n_visitors'] * nw['pg_visitors'] +
        w_df['n_visits'] * nw['pg_visits'] +
        w_df['n_vpv'] * nw['visits_per_visitor_weight'] +
        w_df['n_calls'] * nw['friction_calls_weight'] +
        w_df['n_aht'] * nw['aht_weight'] +
        w_df['n_call_rate'] * nw['call_rate_weight'] +
        w_df['n_dsr'] * nw['desktop_switch_rate_weight'] +
        w_df['n_sw_desk'] * nw['friction_desktop_7day_weight'] +
        w_df['n_eou'] * nw['ease_of_use_weight'] +
        w_df['n_cei'] * nw['cei_top2box_weight']
    )
    
    return w_df.sort_values(by='RawPriority', ascending=False)
