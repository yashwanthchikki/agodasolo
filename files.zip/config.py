"""
Configuration Module

Contains static configurations and column mappings.
Weight configurations are imported from saved_weights.py.
"""

import copy
from saved_weights import BASE_WEIGHTS, PRESET_WEIGHTS

BASE_CONFIG = copy.deepcopy(BASE_WEIGHTS)

CONFIGURATIONS = {}
for preset_name, preset_weights in PRESET_WEIGHTS.items():
    CONFIGURATIONS[preset_name] = copy.deepcopy(preset_weights)

feature_groups = {
    "Volume & Engagement": {
        "pg_visitors": "VISITORS",
        "pg_visits": "VISITS",
        "visits_per_visitor_weight": "Visits_per_Visitor"
    },
    "Satisfaction & CX": {
        "cei_top2box_weight": "CEI_TOPBOX",
        "ease_of_use_weight": "EASE_OF_USE_TOPBOX"
    },
    "Calls ": {
        "friction_calls_weight": "CALLS_7_DAYS",
        "aht_weight": "AVG_AHT",
        "call_rate_weight": "Call_Rate"
    },
    "Desktop Switch ": {
        "desktop_switch_rate_weight": "Desktop_switch_rate",
        "friction_desktop_7day_weight": "SWITCH_TO_DESKTOP"
    }
}

CUSTOM_DISPLAY_NAMES = {
    'VISITORS': 'Visitors',
    'CALLS_7_DAYS': 'Calls (7d)',
    'AVG_AHT': 'Avg AHT (sec)',
    'Desktop_switch_rate': 'Desktop Switch Rate',
    'VISITS': 'Visits',
    'Visits_per_Visitor': 'Visits per Visitor',
    'SWITCH_TO_DESKTOP': 'Desktop Switches',
    'EASE_OF_USE_TOPBOX': 'Ease of Use Score',
    'CEI_TOPBOX': 'CEI Score',
    'Call_Rate': 'Call Rate %'
}

FEATURE_MAP_FOR_DISPLAY = {
    'VISITORS': 'Visitors',
    'VISITS': 'Visits',
    'Visits_per_Visitor': 'Visits/Visitor',
    'CALLS_7_DAYS': 'Calls (7d)',
    'AVG_AHT': 'Avg AHT',
    'Call_Rate': 'Call Rate',
    'Desktop_switch_rate': 'Desktop Switch %',
    'SWITCH_TO_DESKTOP': 'Switches (7d)',
    'EASE_OF_USE_TOPBOX': 'Ease of Use',
    'CEI_TOPBOX': 'CEI'
}
