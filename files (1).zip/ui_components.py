"""
UI Components Module
"""

import streamlit as st
from PIL import Image
import copy
from config import CONFIGURATIONS, feature_groups
from state_management import update_profile_weight


def render_header():
    """Render header with title and logo."""
    header_container = st.container()
    with header_container:
        col_title, col_logo = st.columns([0.7, 0.3])
        
        col_title.markdown(
            "<h1 style='color: #4CAF50; margin-bottom: 0px;'>NetBenefits Page Prioritization</h1>",
            unsafe_allow_html=True
        )
        col_title.markdown("App Page Prioritization Engine", unsafe_allow_html=True)
        
        try:
            image = Image.open("logo.png")
            resized_image = image.resize((500, 100))
            col_logo.image(resized_image, use_container_width=True)
        except FileNotFoundError:
            col_logo.warning("Logo not found.")
        except Exception as e:
            col_logo.warning(f"Could not load logo: {e}")
        
        st.markdown("<hr style='border: 4px solid #4CAF50;'>", unsafe_allow_html=True)


def render_sliders(profile_index, column_container):
    """Render weight sliders for profile."""
    profile = st.session_state.weight_profiles[profile_index]
    slider_key_prefix = f'slider_temp_{profile_index}'
    
    def slider_callback(k):
        new_val = st.session_state[f'{slider_key_prefix}_{k}']
        update_profile_weight(profile_index, k, new_val)
    
    # Profile name and preset
    col_name, col_preset = column_container.columns([0.6, 0.4])
    
    new_name = col_name.text_input(
        "Profile Name",
        profile["name"],
        key=f"name_{profile_index}"
    )
    st.session_state.weight_profiles[profile_index]["name"] = new_name
    
    current_preset_name = st.session_state.get(f"last_preset_{profile_index}", "Balanced")
    preset_options = list(CONFIGURATIONS.keys())
    
    try:
        default_index = preset_options.index(current_preset_name)
    except ValueError:
        default_index = 0
    
    selected_preset = col_preset.selectbox(
        "Apply Preset",
        preset_options,
        index=default_index,
        key=f"preset_{profile_index}"
    )
    
    if current_preset_name != selected_preset:
        st.session_state[f"last_preset_{profile_index}"] = selected_preset
        new_weights = copy.deepcopy(CONFIGURATIONS[selected_preset])
        for key, value in new_weights.items():
            st.session_state.weight_profiles[profile_index][key] = value
        st.rerun()
    
    # Weight sliders in 4 columns
    weight_col_1, weight_col_2, weight_col_3, weight_col_4 = column_container.columns(4)
    
    group_names = list(feature_groups.keys())
    column_maps = {
        weight_col_1: [group_names[0]],
        weight_col_2: [group_names[1]],
        weight_col_3: [group_names[2]],
        weight_col_4: [group_names[3]]
    }
    
    for column, groups in column_maps.items():
        with column:
            for group_name in groups:
                st.markdown(
                    f"**<div style='font-size: 16px; margin-bottom: 5px; color: #4CAF50;'>{group_name}</div>**",
                    unsafe_allow_html=True
                )
                
                with st.container(border=True):
                    for key, label in feature_groups[group_name].items():
                        current_value = profile.get(key, [3])[0]
                        st.slider(
                            label,
                            min_value=1,
                            max_value=5,
                            value=current_value,
                            key=f'{slider_key_prefix}_{key}',
                            on_change=slider_callback,
                            args=(key,)
                        )
