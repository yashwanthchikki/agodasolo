"""
Data Handler Module
"""

import pandas as pd
import streamlit as st


def load_data(filepath='data.xlsx'):
    """Load data from Excel file."""
    try:
        df = pd.read_excel(filepath)
        return df
    except FileNotFoundError:
        st.error(f"Error: '{filepath}' not found.")
        st.stop()
        return None
    except Exception as e:
        st.error(f"Error loading data: {e}")
        st.stop()
        return None


def apply_engagement_filter(df, container=None):
    """Filter by engagement classes."""
    if 'MULTI_PDT_DEEPER_ENGAGEMENT' not in df.columns:
        return df
    
    render_container = container if container else st.sidebar
    
    with render_container.expander("Filter Engagement Classes", expanded=True):
        engagement_classes = df['MULTI_PDT_DEEPER_ENGAGEMENT'].dropna().unique().tolist()
        selected_engagement = [
            cls for cls in engagement_classes 
            if st.checkbox(cls, value=True, key=f'eng_{cls}')
        ]
    
    return df[df['MULTI_PDT_DEEPER_ENGAGEMENT'].isin(selected_engagement)].copy(), selected_engagement


def apply_product_filter(df, selected_engagement, container=None):
    """Filter products for Non-DC engagement."""
    if 'Non-DC' not in selected_engagement:
        return df
    
    if 'PRODUCT' not in df.columns:
        return df
    
    render_container = container if container else st.sidebar
    
    non_dc_rows = df[df['MULTI_PDT_DEEPER_ENGAGEMENT'] == 'Non-DC']
    if not non_dc_rows.empty:
        with render_container.expander("Filter PRODUCT for Non-DC", expanded=False):
            product_classes = non_dc_rows['PRODUCT'].dropna().unique().tolist()
            selected_products = [
                p for p in product_classes 
                if st.checkbox(p, value=True, key=f'prod_{p}')
            ]
        
        filter_non_dc = (df['MULTI_PDT_DEEPER_ENGAGEMENT'] == 'Non-DC')
        filter_product = (~df['PRODUCT'].isin(selected_products))
        df = df[~(filter_non_dc & filter_product)]
    
    return df


def apply_transaction_filter(df, container=None):
    """Filter by PG Transaction status."""
    if 'PG Transaction' not in df.columns:
        return df
    
    render_container = container if container else st.sidebar
    
    render_container.subheader("Additional Filters")
    with render_container.expander("Filter PG Transaction Status", expanded=True):
        pg_options = sorted(df['PG Transaction'].dropna().unique().astype(int).tolist())
        selected_pg_transactions = []
        
        if 0 in pg_options:
            if st.checkbox("Non-Transactional (0)", value=True, key='pg_trans_0_exp'):
                selected_pg_transactions.append(0)
        
        if 1 in pg_options:
            if st.checkbox("Transactional (1)", value=True, key='pg_trans_1_exp'):
                selected_pg_transactions.append(1)
    
    return df[df['PG Transaction'].isin(selected_pg_transactions)].copy()


def apply_response_filter(df, container=None):
    """Filter by satisfaction response count."""
    if 'Satisfaction - CEI #Responses' not in df.columns:
        return df
    
    render_container = container if container else st.sidebar
    
    cei_toggle = render_container.toggle(
        "Require > 30 Sat. Responses", 
        value=False, 
        key='cei_count_toggle'
    )
    
    if cei_toggle:
        return df[df['Satisfaction - CEI #Responses'] >= 30]
    
    return df


def apply_all_filters(df, sidebar_container=None):
    """Apply all filters in sequence."""
    container = sidebar_container if sidebar_container else st.sidebar
    
    container.markdown("---")
    container.markdown("### Data Filters (Universal)")
    
    filtered_df, selected_engagement = apply_engagement_filter(df, container)
    filtered_df = apply_product_filter(filtered_df, selected_engagement, container)
    filtered_df = apply_transaction_filter(filtered_df, container)
    filtered_df = apply_response_filter(filtered_df, container)
    
    return filtered_df
