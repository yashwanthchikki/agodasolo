"""
NetBenefits Page Prioritization Application
"""

import pandas as pd
import streamlit as st

from config import CONFIGURATIONS
from data_handler import load_data, apply_all_filters
from calculations import calculate_priority_df
from state_management import initialize_profiles, add_profile, remove_profile
from ui_components import render_header, render_sliders
from comparison_mode import display_results_for_profile
from visualization import render_exploration_section

st.set_page_config(layout="wide")

# Load data
df = load_data('data.xlsx')

# Render header
render_header()

# Initialize profiles
initialize_profiles()

# Apply filters
filtered_df = apply_all_filters(df, st.sidebar)

# Weight adjustment UI
st.header('Adjust Feature Weights (Scale 1-5)')

col_add, col_remove, _ = st.columns([0.15, 0.15, 0.7])

col_add.button(
    "➕ Add Profile",
    on_click=add_profile,
    use_container_width=True
)

col_remove.button(
    "➖ Remove Last Profile",
    on_click=remove_profile,
    args=(len(st.session_state.weight_profiles) - 1,),
    use_container_width=True
)

st.markdown("<br>", unsafe_allow_html=True)

# Create tabs for profiles
tab_names = [p['name'] for p in st.session_state.weight_profiles]
tabs = st.tabs(tab_names)

for i, profile in enumerate(st.session_state.weight_profiles):
    with tabs[i]:
        slider_container = st.container()
        with slider_container:
            render_sliders(i, slider_container)
        
        st.markdown("---")
        
        priority_df = calculate_priority_df(filtered_df, profile)
        display_results_for_profile(priority_df, profile['name'])

# Visualization section
st.markdown("---")
st.markdown("## Visualization Section")
st.markdown("This area can be used for comparing profiles.")

# Exploration
render_exploration_section(df)

st.markdown("---")
