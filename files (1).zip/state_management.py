"""
State Management Module
"""

import streamlit as st
import copy
from saved_weights import PRESET_WEIGHTS


def initialize_profiles():
    """Initialize session state with default profile."""
    if "weight_profiles" not in st.session_state:
        st.session_state.weight_profiles = []
    
    if not st.session_state.weight_profiles:
        st.session_state.weight_profiles.append({
            "name": "Profile 1 (Balanced)",
            **PRESET_WEIGHTS["Balanced"]
        })


def add_profile():
    """Add new profile with Balanced preset."""
    new_index = len(st.session_state.weight_profiles) + 1
    new_profile = {
        "name": f"Profile {new_index} (Balanced)",
        **PRESET_WEIGHTS["Balanced"]
    }
    st.session_state.weight_profiles.append(new_profile)


def remove_profile(index_to_remove):
    """Remove profile by index."""
    if len(st.session_state.weight_profiles) > 1:
        st.session_state.weight_profiles.pop(index_to_remove)
    else:
        st.error("Cannot remove the last profile.")


def update_profile_weight(profile_index, key, new_value):
    """Update specific weight value."""
    st.session_state.weight_profiles[profile_index][key] = [new_value]
