"""
Configuration Module
"""

import copy
from saved_weights import BASE_WEIGHTS, PRESET_WEIGHTS

BASE_CONFIG = copy.deepcopy(BASE_WEIGHTS)

CONFIGURATIONS = {}
for preset_name, preset_weights in PRESET_WEIGHTS.items():
    CONFIGURATIONS[preset_name] = copy.deepcopy(preset_weights)

feature_groups = {
    "Volume & Engagement": {
        "pg_visitors": "PG Visitors",
        "pg_visits": "PG Visits",
        "visits_per_visitor_weight": "Visits per Visitor"
    },
    "Satisfaction & CX": {
        "cei_top2box_weight": "CEI - Top2Box",
        "ease_of_use_weight": "Ease of Use - Top2Box"
    },
    "Calls Friction": {
        "friction_calls_weight": "Friction - # Calls (7 days)",
        "aht_weight": "Avg. AHT per call",
        "call_rate_weight": "Call Rate (3rd friction metric)"
    },
    "Desktop Switch Friction": {
        "desktop_switch_rate_weight": "Desktop Switch Rate",
        "friction_desktop_7day_weight": "Desktop Switch (7 days)"
    }
}

CUSTOM_DISPLAY_NAMES = {
    'PG Visitors': 'PG Visitors',
    'PG Friction - # Calls within 7 days': 'Calls within 7 days',
    'Avg. AHT per call': 'Average Handle Time per Call (sec)',
    'Desktop Switch Rate': 'Rate of Switching to Desktop',
    'PG Visits': 'PG Visits',
    'PG Visits per Visitor': 'Average Visits per Visitor',
    'PG Friction - Switch to Desktop within 7 days': 'Desktop Switches (7 Days)',
    'Ease of Use - Top2Box': 'Ease of Use (Top 2 Box)',
    'CEI - Top2Box': 'Customer Experience Index (Top 2 Box)',
    'Call Rate': 'Call Rate (%)'
}

FEATURE_MAP_FOR_DISPLAY = {
    'PG Visitors': 'PG Visitors',
    'PG Visits': 'PG Visits',
    'PG Visits per Visitor': 'Visits/Visitor',
    'PG Friction - # Calls within 7 days': 'Calls (7d)',
    'Avg. AHT per call': 'Avg AHT',
    'Call Rate': 'Call Rate',
    'Desktop Switch Rate': 'Desktop Switch %',
    'PG Friction - Switch to Desktop within 7 days': 'Switches (7d)',
    'Ease of Use - Top2Box': 'Ease of Use',
    'CEI - Top2Box': 'CEI'
}
