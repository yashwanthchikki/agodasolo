"""
Calculations Module
"""

import pandas as pd


def normalize(series):
    """Normalize series to 0-1 scale."""
    if series.empty or series.max() == series.min():
        return pd.Series(0, index=series.index)
    return (series - series.min()) / (series.max() - series.min())


def normalize_weights(weights_dict):
    """Normalize weights from 1-5 scale to 0-1 range."""
    from saved_weights import BASE_WEIGHTS
    
    weight_keys = list(BASE_WEIGHTS.keys())
    values = [weights_dict.get(k, [3])[0] for k in weight_keys]
    
    min_val = min(values)
    max_val = max(values)
    
    if max_val == min_val:
        return {k: 1/len(weight_keys) for k in weight_keys}
    
    normalized = {}
    for k in weight_keys:
        v_int = weights_dict.get(k, [3])[0]
        normalized[k] = (v_int - min_val) / (max_val - min_val)
    
    return normalized


def calculate_priority_df(df_input, weight_profile):
    """
    Calculate priority scores based on normalized metrics and weights.
    Satisfaction metrics are inverted (100 - score) before normalization.
    """
    working_df = df_input.copy()
    
    # Normalize metrics
    working_df['Visitors'] = normalize(working_df['PG Visitors'])
    working_df['Visits'] = normalize(working_df['PG Visits'])
    working_df['Visits per Visitor'] = normalize(working_df['PG Visits per Visitor'])
    working_df['Friction - # Calls within 7 days'] = normalize(working_df['PG Friction - # Calls within 7 days'])
    working_df['Avg. AHT per call'] = normalize(working_df['Avg. AHT per call'])
    working_df['Desktop Switch Rate'] = normalize(working_df['Desktop Switch Rate'])
    working_df['Switch to Desktop within 7 days'] = normalize(working_df['PG Friction - Switch to Desktop within 7 days'])
    working_df['Call Rate Normalized'] = normalize(working_df['Call Rate'])
    working_df['CEI - Top2Box Normalized'] = normalize(100 - working_df['CEI - Top2Box'])
    working_df['Ease of Use - Top2Box Normalized'] = normalize(100 - working_df['Ease of Use - Top2Box'])
    
    # Normalize weights
    normalized_weights = normalize_weights(weight_profile)
    
    # Calculate priority
    working_df['RawPriority'] = (
        working_df['Visitors'] * normalized_weights['pg_visitors'] +
        working_df['Visits'] * normalized_weights['pg_visits'] +
        working_df['Visits per Visitor'] * normalized_weights['visits_per_visitor_weight'] +
        working_df['Friction - # Calls within 7 days'] * normalized_weights['friction_calls_weight'] +
        working_df['Avg. AHT per call'] * normalized_weights['aht_weight'] +
        working_df['Call Rate Normalized'] * normalized_weights['call_rate_weight'] +
        working_df['Desktop Switch Rate'] * normalized_weights['desktop_switch_rate_weight'] +
        working_df['Switch to Desktop within 7 days'] * normalized_weights['friction_desktop_7day_weight'] +
        working_df['Ease of Use - Top2Box Normalized'] * normalized_weights['ease_of_use_weight'] +
        working_df['CEI - Top2Box Normalized'] * normalized_weights['cei_top2box_weight']
    )
    
    return working_df.sort_values(by='RawPriority', ascending=False)
