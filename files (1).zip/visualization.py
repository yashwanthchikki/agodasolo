"""
Visualization Module
"""

import streamlit as st
import matplotlib.pyplot as plt
import plotly.express as px
import numpy as np
from sklearn.linear_model import LinearRegression
from config import CUSTOM_DISPLAY_NAMES


def render_exploration_section(df):
    """Render data exploration section."""
    st.markdown("---")
    st.header("Column-wise Data Exploration")
    
    plot_type = st.selectbox("Select plot type", ["Bar (Top 10)", "Scatter"], key='plot_type_select')
    base_columns = list(CUSTOM_DISPLAY_NAMES.keys())
    
    if plot_type == "Scatter":
        st.markdown("##### Scatter Plot Configuration")
        
        if "selected_x_s" not in st.session_state:
            st.session_state["selected_x_s"] = base_columns[0]
        if "selected_y_s" not in st.session_state:
            st.session_state["selected_y_s"] = base_columns[1]
        
        selected_x = st.selectbox(
            "Select column for X-axis",
            base_columns,
            index=base_columns.index(st.session_state["selected_x_s"]),
            key="scatter_x_s"
        )
        selected_y = st.selectbox(
            "Select column for Y-axis",
            base_columns,
            index=base_columns.index(st.session_state["selected_y_s"]),
            key="scatter_y_s"
        )
        selected_size = st.selectbox(
            "Select column for marker size (optional)",
            [None] + base_columns,
            key="scatter_size_s"
        )
        selected_color = st.selectbox(
            "Select column for marker color (optional)",
            [None] + base_columns,
            key="scatter_color_s"
        )
        
        st.session_state["selected_x_s"] = selected_x
        st.session_state["selected_y_s"] = selected_y
        
    else:
        st.markdown("##### Single Variable Configuration")
        if "selected_col_s" not in st.session_state:
            st.session_state["selected_col_s"] = base_columns[0]
        
        selected_col = st.selectbox(
            "Select column for analysis",
            base_columns,
            index=base_columns.index(st.session_state["selected_col_s"]),
            key="selected_col_s"
        )
    
    if st.button("Generate Plot"):
        if plot_type == "Bar (Top 10)":
            generate_bar_plot(df, selected_col)
        elif plot_type == "Scatter":
            generate_scatter_plot(df, selected_x, selected_y, selected_size, selected_color)


def generate_bar_plot(df, column_name):
    """Generate bar chart for top/bottom 10 pages."""
    ascending_order = 'Top2Box' in column_name
    
    top_df = df[['PAGE_GROUP', column_name]].dropna().sort_values(
        by=column_name,
        ascending=ascending_order
    ).head(10)
    
    fig, ax = plt.subplots(figsize=(8, 6))
    ax.barh(top_df['PAGE_GROUP'], top_df[column_name], color="darkorange")
    
    title_prefix = "Bottom 10" if ascending_order else "Top 10"
    label_x = CUSTOM_DISPLAY_NAMES.get(column_name, column_name)
    ax.set_title(f"{title_prefix} Pages by {label_x}", fontsize=14)
    ax.set_xlabel(label_x, fontsize=12)
    ax.invert_yaxis()
    plt.tight_layout()
    st.pyplot(fig)


def generate_scatter_plot(df, x_col, y_col, size_col, color_col):
    """Generate scatter plot with regression line."""
    cols_to_plot = [x_col, y_col]
    if size_col:
        cols_to_plot.append(size_col)
    if color_col:
        cols_to_plot.append(color_col)
    
    df_plot = df[['PAGE_GROUP'] + cols_to_plot].dropna().copy()
    
    if df_plot.empty:
        st.warning("No valid data to plot.")
        return
    
    # Normalize size column if provided
    size_col_name = None
    if size_col:
        df_plot['size_norm'] = (
            (df_plot[size_col] - df_plot[size_col].min()) /
            (df_plot[size_col].max() - df_plot[size_col].min())
        ) * 40 + 10
        size_col_name = 'size_norm'
    
    # Calculate regression
    X = df_plot[[x_col]]
    Y = df_plot[[y_col]]
    model = LinearRegression()
    model.fit(X.values.reshape(-1, 1), Y.values.reshape(-1, 1))
    r_sq = model.score(X.values.reshape(-1, 1), Y.values.reshape(-1, 1))
    
    label_x = CUSTOM_DISPLAY_NAMES.get(x_col, x_col)
    label_y = CUSTOM_DISPLAY_NAMES.get(y_col, y_col)
    
    st.info(f"Linear correlation ($R^2$) between {label_x} and {label_y}: **{r_sq:.3f}**")
    
    # Create scatter plot
    fig = px.scatter(
        df_plot,
        x=x_col,
        y=y_col,
        size=size_col_name,
        color=color_col if color_col else None,
        hover_name='PAGE_GROUP',
        title=f"{label_x} vs {label_y}",
        labels={x_col: label_x, y_col: label_y},
        color_continuous_scale="Viridis" if color_col else None
    )
    
    fig.update_traces(marker=dict(opacity=0.7))
    
    # Add regression line
    x_vals = np.linspace(X.min().iloc[0], X.max().iloc[0], 100).reshape(-1, 1)
    y_vals = model.predict(x_vals)
    
    fig.add_scatter(
        x=x_vals.flatten(),
        y=y_vals.flatten(),
        mode='lines',
        name='Regression Line',
        line=dict(color='red', width=3)
    )
    
    st.plotly_chart(fig, use_container_width=True)
